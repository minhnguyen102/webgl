var canvas = document.querySelector("#test");
var context = canvas.getContext("2d");
context.fillStyle = "rgba(255, 255, 0, 1)";
context.fillRect(150, 10, 120 , 120)